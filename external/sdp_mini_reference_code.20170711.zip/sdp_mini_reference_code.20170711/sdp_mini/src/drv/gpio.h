#ifndef _GPIO_H__
#define _GPIO_H__
#include "common/common.h"

void init_gpio(void);
void maky(void);

#endif                          /* _GPIO_H__ */
